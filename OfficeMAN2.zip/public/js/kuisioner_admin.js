$(document).ready(function () {
    fetchData();
});

function fetchData() {
    let table = $(".yajra-datatable").DataTable({
        destroy: true,
        processing: true,
        serverSide: true,
        ajax: app_path.base_path + "/list-kuisioner",
        columns: [
            {
                data: "DT_RowIndex",
                name: "DT_RowIndex",
            },
            {
                data: "nama",
                name: "nama",
            },
            {
                data: "usia",
                name: "usia",
            },
            {
                data: "pendidikan",
                name: "pendidikan",
            },
            {
                data: "pekerjaan",
                name: "pekerjaan",
            },
            {
                data: "no_1",
                name: "no_1",
            },
            {
                data: "no_2",
                name: "no_2",
            },
            {
                data: "no_3",
                name: "no_3",
            },
            {
                data: "no_4",
                name: "no_4",
            },
            {
                data: "no_5",
                name: "no_5",
            },
            {
                data: "no_6",
                name: "no_6",
            },
            {
                data: "no_7",
                name: "no_7",
            },
            {
                data: "no_8",
                name: "no_8",
            },
            {
                data: "no_9",
                name: "no_9",
            },
            {
                data: "no_10",
                name: "no_10",
            },
            {
                data: "saran",
                name: "saran",
            },
        ],
    });
}
