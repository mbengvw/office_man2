@extends('admin.main')

@section('content')
    <div class="row">
        <div class="col-lg-12 col-xs-6">
            <div class="container mt-5">
                <h2 class="mb-4">Buku Tamu</h2>
                <div class="table-responsive">
                    <table class="table table-bordered yajra-datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Usia</th>
                                <th>Pendidikan</th>
                                <th>Pekerjaan</th>
                                <th>1</th>
                                <th>2</th>
                                <th>3</th>
                                <th>4</th>
                                <th>5</th>
                                <th>6</th>
                                <th>7</th>
                                <th>8</th>
                                <th>9</th>
                                <th>10</th>
                                <th>Saran</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /.row (main row) -->
@endsection

@section('script')
    <script>
        const app_path = {
            base_path: "{{ route('admin.index') }}",
        };
    </script>

    <script src="{{ asset('js/kuisioner_admin.js') }}" defer></script>
@endsection
