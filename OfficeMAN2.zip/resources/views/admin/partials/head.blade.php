<title>E-Offive MAN 2</title>
<meta name="csrf-token" content="{{ csrf_token() }}">
