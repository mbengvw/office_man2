<title>SAISNG</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php /**PATH /home/mbeng/LaravelProjects/office-man2/resources/views/admin/partials/_head.blade.php ENDPATH**/ ?>