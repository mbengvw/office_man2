<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center" style="margin-top: 50px;">
            <h2>
                Wilujeng Sumping Administrator...
            </h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mbeng/LaravelProjects/office-man2/resources/views/admin/home.blade.php ENDPATH**/ ?>