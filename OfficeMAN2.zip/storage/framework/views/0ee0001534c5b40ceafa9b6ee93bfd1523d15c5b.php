<!doctype html>
<html <?php echo app('translator')->get('en'); ?>>

<head>
    <?php echo $__env->make('admin.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <?php echo $__env->make('admin.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('script'); ?>
    <script>
        $(document).ready(function() {
            const menuItems = document.getElementsByClassName("nav-link");
            const navItems = document.getElementsByClassName("nav-item");

            for (let i = 0; i < menuItems.length; i++) {
                if (menuItems[i].href === location.href) {
                    navItems[i].className += " active"
                }
            }
        });
    </script>
</body>

</html>
<?php /**PATH /home/mbeng/LaravelProjects/office-man2/resources/views/admin/main.blade.php ENDPATH**/ ?>