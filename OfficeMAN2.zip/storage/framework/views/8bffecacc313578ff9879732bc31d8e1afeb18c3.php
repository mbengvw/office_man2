<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-xs-6">
            <div class="container mt-5">
                <h2 class="mb-4">Buku Tamu</h2>
                <table class="table table-bordered yajra-datatable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>No. HP</th>
                            <th>Alamat</th>
                            <th>Tujuan</th>
                            <th>Keperluan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- /.row (main row) -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const app_path = {
            base_path: "<?php echo e(route('admin.index')); ?>",
        };
    </script>

    <script src="<?php echo e(asset('js/buku_tamu_admin.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mbeng/LaravelProjects/office-man2/resources/views/admin/buku_tamu/list_buku_tamu.blade.php ENDPATH**/ ?>