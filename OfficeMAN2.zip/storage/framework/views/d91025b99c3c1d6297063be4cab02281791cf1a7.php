<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <div class="container">
        <a class="navbar-brand" href="#">E-Office MAN 2 Kuningan</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse">

            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Home <span
                            class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('buku-tamu.index')); ?>">Buku Tamu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('kuisioner.index')); ?>">Data Kuisioner</a>
                </li>

                

            </ul>

        </div>
    </div>

</nav>
<?php /**PATH /home/mbeng/LaravelProjects/office-man2/resources/views/admin/partials/nav.blade.php ENDPATH**/ ?>