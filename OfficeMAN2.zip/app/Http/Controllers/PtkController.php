<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PtkController extends Controller
{
    //
}
