<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kuisioner;
use Yajra\DataTables\Facades\DataTables;

class KuisionerController extends Controller
{
    public function index()
    {
        return view('admin.kuisioner.list_kuisioner');
    }

    public function list_all(Request $request)
    {
        if ($request->ajax()) {
            $data = Kuisioner::all();
            return DataTables::of($data)
                ->addIndexColumn()
                ->make(true);
        }
    }
}
